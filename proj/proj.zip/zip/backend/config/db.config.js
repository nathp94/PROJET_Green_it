module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "20040315",
    DB: "ecommerce_db",
    dialect: "mysql",
};
